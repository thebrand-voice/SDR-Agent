# Brand Voice Guidelines — The Brand Voice AI (Christine Laikind)

**Living document, v2.** Supplied directly by Christine — merges founder positioning with real LinkedIn post-performance analysis. This is the authoritative voice source for Christine; it supersedes the seeded profile that was in `voice-profile.md` before this document arrived. Update as new examples come in.

This file is the full reference. `voice-profile.md` carries the condensed, practical version every skill actually drafts from — read that first; come here for the underlying data and reasoning, or when drafting something long-form (a LinkedIn post, a blog piece) where the two-register distinction below matters directly.

---

## 1. Overview

Two distinct voice registers show up in the content so far, and they serve different jobs:

| Register | Job it does | Example |
|---|---|---|
| Personal Narrative Voice | Builds trust, humanizes the brand, invites connection | The Italy/bell-ringing post |
| Teaching/Coach Voice | Delivers value, positions expertise, drives action | The "Who I'm Not For" exercise post |

**Headline finding (5 posts analyzed):** The one Personal Narrative post reached 2,032 impressions. All four Teaching/Coach posts landed within a tight 108–128 range — roughly a 15–19x reach gap — despite consistently strong, specific, well-structured writing across all four. See Section 6 for the full breakdown and working hypothesis. This is a real, data-confirmed pattern, not a stylistic guess — it should actively shape the content mix going forward, not just the writing style within each post.

**Who we serve** (from founder positioning): B2B printing, retail, DTC, and manufacturing brands — specifically small printers, manufacturers, and product-based businesses that are excellent at their craft but overwhelmed by content creation.

**Core belief:** Printing, manufacturing, and product-based businesses are built on relationships. Content should scale without losing the soul of the company. This shows up concretely in the data: the posts that "sound most human" (Narrative Voice) are also the ones that perform best.

---

## 2. Voice & Tone

### Personal Narrative Voice
- Tone: honest, unresolved, quietly emotional — not polished into a tidy ending.
- Grounded in specific, sensory detail rather than abstract statements about feelings. Example: not "cancer was hard," but "crossing off each day on a calendar."
- Resists false triumph. Gratitude is real but paired with the ongoing, harder truth ("still in maintenance," "effects of radiation are still healing"). This honesty is likely a major driver of engagement — it invites people to relate rather than just admire.
- Short, declarative sentences. Often one thought per line.
- Understated humor as a release valve ("it is not pretty" — re: not sharing an exercise bike photo).

### Teaching/Coach Voice
- Tone: direct, imperative, second-person ("you"). Reads like a coach giving an assignment, not a guru giving a lecture.
- Concrete fill-in-the-blank examples, drawn from real client types (bookkeeper, sign shop), not generic hypotheticals.
- Names the discomfort of the exercise up front ("This one feels a little uncomfortable, which is exactly why it works") — a recurring, deliberate move: naming resistance before asking for action.
- Ends with an open question / homework, inviting the reader to report back.

### Shared traits across both registers
- Plain language, no jargon. Nothing that requires marketing vocabulary to understand.
- Short paragraphs — often 1–2 sentences. Built for skimming on LinkedIn.
- Specificity over abstraction, always. Real numbers (miles ridden, days on a calendar), real trade examples (bookkeeper, sign shop), never vague claims.
- "Clarity" is a core brand word — appears in hashtags and as a throughline concept (message clarity, brand clarity, site clarity).

### Tone by context (carried from founder positioning — apply once more channel data exists)

| Context | Tone |
|---|---|
| Email / partner & retention content | Friendly, personal, relationship-first |
| Blog / behind-the-production storytelling | Clear, patient, explanatory |
| Sales / objection-handling | Concede honestly first, then draw the real distinction (mirrors Example C — see Section 6) |

### The "We" Rule (Website & Email) — Decided

This is a solo practice, not a company with a team. **"We" is never corporate/institutional — it's collaborative**, meaning "you and me, working on this together," not "our organization."

- Speak directly to the visitor/reader at their level — meet them in the pain point they're already feeling (overwhelmed, content is scattered, no time to turn expertise into words), not from above as an authority lecturing down.
- "We" = "let's figure this out together" (e.g., "We'll turn what you already know into content that sounds like you" — not "Our team delivers content solutions").
- "I" still shows up for founder credibility and story (20+ years, personal experience) — but the offer and process language defaults to collaborative "we/let's/you and I."
- This is the natural extension of the Teaching/Coach voice's second-person directness — just applied to prose instead of an exercise.

---

## 3. We Are / We Are Not

| We Are | We Are Not |
|---|---|
| Honest and specific, even when the story isn't resolved | Wrapped-in-a-bow or falsely triumphant |
| Direct — a coach giving an assignment | A guru giving a lecture |
| Grounded in real trade examples (bookkeeper, sign shop) | Reliant on generic hypotheticals |
| Confident enough to name resistance before asking for action | Avoidant of the reader's discomfort |
| Human-centered, relationship-first | Robotic, generic-sounding, or appeal-to-everyone |
| Plain-spoken | Full of marketing jargon |

---

## 4. Vocabulary

**Recurring words/phrases to reuse:**
- Clarity / Message Clarity / Brand Clarity
- "Who you're FOR" / "who you're not for"
- Plain trade nouns as concrete stand-ins: bookkeeper, sign shop, small business owner
- "Here's the thing" — direct, conversational transition (pattern noted; confirm with more examples)

**Words/phrases to avoid:**
- Generic marketing-speak: "synergy," "leverage," "unlock your potential," "game-changer"
- Overly polished resolution language: "everything happens for a reason," "and that's when I knew..." — undercuts the honesty driving engagement
- Appeal-to-everyone phrasing in client-facing copy: "affordable options for every budget" — explicitly flagged as language that repels the right customer

---

## 5. Structural Patterns

**Personal Narrative Voice:**
- Open with a specific, concrete moment (not a theme statement)
- Let the hard/honest part sit without resolving it too fast
- Close with grounded, specific gratitude — not a general uplifting statement
- Hashtags at the end can feel disconnected from the emotional tone — worth testing fewer, more integrated tags

**Teaching/Coach Voice:**
- Name the exercise/technique in one line
- Name the discomfort or resistance up front
- Give a fill-in-the-blank example using a real, relatable trade
- Ask the reader to do something concrete
- End with an open-ended question inviting a reply

---

## 6. Worked Examples & Performance Data

| Example | Post | Register | Impressions | Notes |
|---|---|---|---|---|
| A | Italy/Bell | Narrative | 2,032 (119 likes, 26 comments, ~7.1% engagement) | Concrete image, unresolved honesty, earned gratitude |
| B | "Who I'm Not For" | Teaching | 128 | Strong structure; low reach possibly algorithmic |
| C | "Ask ChatGPT to review my site?" | Teaching | 108 | Objection-handling; honest concession mirrors Narrative-voice trust move |
| D | "Will I lose my data if I leave my bookkeeper?" | Teaching | 108 | Arguably strongest of the four; copy-pasteable line; 5 hashtags (rules out hashtag count as the variable) |
| E | "Your next client already asked ChatGPT about you" | Teaching | 112 | Series opener; strong hook and specificity still capped at ceiling |

**Working hypothesis:** LinkedIn's distribution likely rewards posts that get fast, low-friction engagement (likes/comments in the first 30–60 minutes). Narrative posts invite personal relating ("I've been through something similar"), generating that faster than Teaching/Coach posts, which ask the reader to think or apply something before commenting. The teaching content isn't failing at its actual job (positioning, trust-building, giving real value) — it's failing at triggering the early-engagement algorithm specifically.

This is a pattern, not a hunch: four straight Teaching/Coach posts (B–E) landed in a 20-impression band (108–128), regardless of hook strength, specificity, or hashtag count.

**Note on scope:** this performance data is about organic LinkedIn *posts* (one-to-many). It does not directly transfer to one-to-one LinkedIn outreach messages or cold email (`prospect-bookkeepers` territory) — different motion, different audience, no algorithmic distribution to win. What does transfer: the tone principles (honesty over false triumph, specificity over abstraction, naming resistance before asking for action) and the vocabulary rules in Section 4.

---

## 7. Do / Don't

**Do:**
- Lead with one specific, concrete detail instead of a theme statement
- Let discomfort or unresolved truth sit in the post rather than tying it up
- Use real trade/client examples instead of hypotheticals
- Name the reader's likely resistance before asking them to act
- Open Teaching/Coach posts with a specific personal or client moment before pivoting to the lesson — early data suggests this may break the reach ceiling

**Don't:**
- Don't reach for a tidy, uplifting ending that resolves everything
- Don't use appeal-to-everyone language in client-facing copy
- Don't lean on marketing jargon
- Don't let hashtags feel like a tonal switch from the body of the post
- Don't assume a Teaching/Coach post underperformed because it was poorly written — check format/register first

---

## 8. Website & Email Voice — Applied

**Rule of thumb:** open with the visitor's pain point in their own language, at their level — not your credentials, not your process. Credentials and process come after they feel understood.

This is the register closest to what `prospect-bookkeepers` drafts — a stranger meeting the brand for the first time, needs the pain point named fast, low context assumed (versus a warm LinkedIn audience already following Christine's story).

**Website hero example (draft, for review):**
> You know your craft inside and out. The presses, the finishes, the deadlines nobody else could hit.
>
> But turning that into content that actually reaches buyers, dealers, and partners? That's the part that keeps sliding to the bottom of the list.
>
> Let's fix that — together.

**Website "how we work" example (collaborative "we," not corporate):**
> We start with a conversation. Not a questionnaire — an actual conversation about how you talk, what you're proud of, and what you wish people understood about your business. From there, we build a content system around your real voice, not a generic template.

**Email opener example (nurture/welcome):**
> Hey [name] — quick note. If your content's felt scattered or like it's always last on the list, you're not alone. That's exactly why we're here. Let's start with one thing that's been nagging at you...

(Confidence: Medium-Low on the website/email examples — these are illustrative, built from the "We" Rule above, not drawn from real sent mail. Swap in real website/email drafts once available, same as the LinkedIn analysis in Section 6.)

---

## 9. Open Questions / Next Data Points

- Highest priority: run a genuine hybrid test — open a Teaching/Coach post with a specific personal or client moment before pivoting to the lesson. Four straight pure-teaching posts have saturated that side of the comparison; this is the most valuable next data point.
- Would a second Narrative post also land near 2,000+, confirming Example A wasn't itself an outlier?
- Does the "series opener" structure (Example E) change performance over the following posts in that series?
- Is there a minimum-viable "personal stakes" sentence to standardize into Teaching/Coach posts, given how consistent the gap now looks?
- Confirm which recurring phrases (e.g. "Here's the thing") are intentional brand vocabulary vs. one-off word choices.
- Carried from v1: do you have email or blog performance data to build out the "tone by context" section with the same rigor as the LinkedIn analysis?
