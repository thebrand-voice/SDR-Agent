# Output Template

How the batch is presented before anything is created. Chat carries the recap and the approval question; the artifact carries the full drafts.

---

## Chat recap (before the artifact)

```
7 bookkeepers ready to go, 2 skipped (missing LinkedIn URL: Greg Dangar,
Priya Shah — fill those in and re-run to include them).

Angles: 4 Behind-the-Production Storytelling, 2 Brand Foundations Sprint,
1 Partner & Retention Content.

Full drafts below. Tell me what to change, then I'll create the Gmail
drafts and the LinkedIn copy.
```

---

## Artifact layout (house style, `../../shared/artifact-style.md`)

One panel per lead:

```
┌─────────────────────────────────────────────────────────┐
│ Douglas Beard · Beard Bookkeeping Solutions               │
│ [Behind-the-Production Storytelling]                      │
│ Hook: Specializes in contractor/trades bookkeeping, no    │
│ visible content presence despite the niche.                │
│                                                             │
│ EMAIL — Day 0                              [Copy block]   │
│ Subject: Contractor books                                  │
│ Hi Douglas, ...                                            │
│                                                             │
│ LINKEDIN — Day 4                                           │
│ Connection note (287/300 chars)            [Copy block]   │
│ Hi Douglas — came across...                                │
│ Message after accept                       [Copy block]   │
│ Thanks for connecting...                                   │
│                                                             │
│ EMAIL — Day 11 follow-up (angle only, drafted closer to    │
│ the date)                                                   │
│ One more thing worth mentioning...                         │
└─────────────────────────────────────────────────────────┘
```

Each email and LinkedIn block is a `.copy-block` component (per the house
style) so any single message can be copied independently. Skipped rows get
a short list at the top of the page, name plus what's missing, not a full
card.

---

## After approval

Chat confirms what was actually created, naming names — not a count alone:

```
Created 7 Gmail drafts (Day 0 emails) in your drafts folder. LinkedIn copy
for all 7 is in the page above for you to paste. Sheet updated: all 7 rows
marked "Drafted — Sep 24," Day 11 due dates set.

Skipped: Greg Dangar, Priya Shah — no LinkedIn URL on file.
```
