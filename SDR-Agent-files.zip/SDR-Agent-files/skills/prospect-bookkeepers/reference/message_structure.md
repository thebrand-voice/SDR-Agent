# Message Structure

The bookkeeper list is small and curated, not a spray list — three touches, not four, and every one grounded in the specific firm.

---

## Voice rules specific to this register (from `../../../shared/christine-brand-voice-guidelines.md`, Section 8)

A cold email or a first LinkedIn message is a stranger meeting the brand for the first time — the register closest to the guidelines doc's "Website & Email Voice," not the LinkedIn *posting* voice. Three rules from that document apply directly to every touch in this sequence:

- **Open with the reader's pain point, in their language — not Christine's credentials or process.** Credentials come after they feel understood, never before. "You know bookkeeping inside and out... turning that into content that reaches clients? That's the part that keeps sliding to the bottom of the list" is the shape; "I've spent 20 years helping businesses..." is not, in message 1.
- **"We" is always collaborative, never corporate.** This is a solo practice. "Let's see if that's a fit" and "we'll build this together" are right; "our team" or anything implying staff beyond Christine is wrong, always.
- **No tidy, falsely-triumphant endings**, especially on the Day 11 follow-up. If there's genuinely nothing new to say, say that plainly and close cleanly — don't manufacture uplift.

Vocabulary: prefer "clarity" / "message clarity" language where it fits naturally, and plain trade nouns ("bookkeeper," "bookkeeping firm") over abstractions. Never use the words on the guidelines doc's avoid-list (Section 4) — "synergy," "leverage," "solutions," "unlock your potential," "game-changer," "affordable options for every budget," or similar appeal-to-everyone phrasing.

---

## The cadence

| # | Day | Channel | Angle | Ceiling |
|---|---|---|---|---|
| 1 | 0 | Email | The hook, one offer angle, one small ask | 120 words |
| 2 | +4 | LinkedIn | Connection note, then a message once accepted | note ≤300 characters; message ≤80 words |
| 3 | +11 | Email | A different angle or a useful piece of content, clean close if no reply | 70 words |

Stop the sequence the moment the person replies on either channel, or asks to be left alone. Record the stop reason on the sheet row.

---

## The three offer angles

Pick the one that actually fits the firm from Step 2's research — never default to the same angle for everyone in a batch, or the list starts reading like a mail merge even though each email is technically personalized.

**Brand Foundations Sprint** — fits a firm that has no real content presence yet: no LinkedIn posts, a bare-bones website, nothing that explains who they serve. The pitch is "let's build the thing you don't have."

**Behind-the-Production Storytelling** — fits a firm that clearly has expertise and client trust but nothing translating it into content — long tenure, specific niche (construction, real estate, restaurants), no posts showing that expertise. The pitch is "you know this cold, it's just not written down anywhere."

**Partner & Retention Content** — fits a firm that explicitly serves other businesses as partners or refers work (mentions dealers, brokers, or referral relationships) or has an existing client base worth nurturing. The pitch is "keep the people you already have engaged."

If nothing distinguishes the firm, default to Behind-the-Production Storytelling — bookkeepers as a category are usually strong on expertise and thin on content, and that framing is honest even without a specific trigger.

---

## Email 1 — the hook

Open with the specific thing found in Step 2, not a compliment. State the ask in the first or second sentence pattern from `../../outreach-composer/reference/slop_test.md` — small and answerable, e.g. "Worth 15 minutes to see if this is a fit?" rather than "let me know if you'd like to explore."

```
Bad opener:  I hope this finds you well! I came across your firm and was
             really impressed by your work with small businesses.

Good opener: Noticed Beard Bookkeeping Solutions works mostly with
             contractors and trades — that's a specific enough niche that
             most of your growth is probably word of mouth right now.
```

## LinkedIn — connection note, then message

**Connection note (≤300 characters, sent with the invite):** Reference the same hook in one sentence. No pitch — the ask is just the connection.

```
Hi Douglas — came across Beard Bookkeeping Solutions while researching
firms that specialize in contractor books. Would love to connect.
```

**Message after they accept (≤80 words):** This is where the actual pitch goes, in the same voice as the email, referencing the same hook so it reads as one person reaching out on two channels, not two separate campaigns.

## Email 2 (Day 11) — the follow-up

Never "just following up." Give it new content: a genuinely useful observation (a content gap noticed on their site, a stat about referral-driven bookkeeping firms), or — if there's truly nothing new to say — a clean, low-pressure close that leaves the door open.

```
Bad:  Just wanted to follow up on my last email in case you missed it.

Good: One more thing worth mentioning — most of the bookkeeping firms I
      talk to don't realize LinkedIn posts from the owner personally
      outperform the firm page by a wide margin. Happy to show you what
      that looks like if it's useful. Either way, I'll leave it here.
```

---

## Timing

Send email touches Tuesday–Thursday, 8–10am. Send LinkedIn connection requests any weekday; avoid Monday mornings and Friday afternoons on both channels — the standard `outreach-composer` guidance in `../../outreach-composer/reference/sequence_patterns.md` applies.
