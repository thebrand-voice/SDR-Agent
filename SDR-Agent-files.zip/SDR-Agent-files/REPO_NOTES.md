# SDR-Agent

This repo holds the real, unzipped file tree for Christine's **Small Business** Cowork plugin — the same plugin delivered earlier as a `.plugin` download, now version-controlled here instead of as a binary.

The piece this repo exists for is the bookkeeper prospecting agent, internally nicknamed **"Alison"**:

- `skills/prospect-bookkeepers/SKILL.md` — the agent itself: reads the "Bookkeeper Prospect List" Google Sheet, researches a hook per firm, drafts a 3-touch email + LinkedIn sequence in Christine's voice, stages everything for approval (nothing auto-sends), creates approved Gmail drafts, and logs the touch to the sheet and to Brevo.
- `shared/voice-profile.md` and `shared/christine-brand-voice-guidelines.md` — Christine's real brand voice, shared across every skill in the plugin that drafts in her name.
- `skills/smb-router/SKILL.md` — the trigger-phrase router, including "have Alison run the batch" / "ask Alison to prospect the bookkeepers."

**"Alison" is an internal nickname for addressing this skill in conversation only.** It never appears as a signature or persona in outreach — every draft is written and signed as Christine herself.

The rest of the tree (`skills/*`) is the broader Small Business plugin this agent lives inside — trigger phrases, shared voice profile, and shared gotcha files are reused across all of it, which is why the full plugin ships together rather than just the one skill.

## Updating this repo

When the plugin changes, the updated files can be copied over this tree, committed, and pushed the same way — this repo is a mirror of `.claude-plugin/plugin.json` + `skills/` + `shared/`, kept in sync manually rather than automatically.
